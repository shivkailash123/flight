package flight;

import java.util.List;

public class LocationEntity {

	String locationName;
	String latitude;
	String longitude;
	FlightEntity flightEntities;
	String demandCofficient;

	@Override
	public String toString() {
		return "LocationEntity [locationName=" + locationName + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", flightEntities=" + flightEntities + ", demandCofficient=" + demandCofficient + "]";
	}

	public LocationEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocationEntity(String locationName, String latitude, String longitude,
			String demandCofficient) {
		super();
		this.locationName = locationName;
		this.latitude = latitude;
		this.longitude = longitude;
		this.demandCofficient = demandCofficient;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public FlightEntity getFlightEntities() {
		return flightEntities;
	}

	public void setFlightEntities(FlightEntity flightEntities) {
		this.flightEntities = flightEntities;
	}

	public String getDemandCofficient() {
		return demandCofficient;
	}

	public void setDemandCofficient(String demandCofficient) {
		this.demandCofficient = demandCofficient;
	}

}

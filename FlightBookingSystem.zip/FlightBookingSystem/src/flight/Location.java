package flight;

public class Location {
	public Location(String name, double lat, double lon, double demand) {

	}

	public Location() {

	}

	// Implement the Haversine formula - return value in kilometres
	public static double distance(LocationEntity l1, LocationEntity l2) {
		// distance between latitudes and longitudes

		double lat1 = Double.parseDouble(l1.getLatitude());
		double lon1 = Double.parseDouble(l1.getLongitude());
		double lat2 = Double.parseDouble(l2.getLatitude());
		double lon2 = Double.parseDouble(l2.getLongitude());

		double dLat = Math.toRadians(lat2 - lat1);
		double dLon = Math.toRadians(lon2 - lon1);

		// convert to radians
		lat1 = Math.toRadians(lat1);
		lat2 = Math.toRadians(lat2);

		// apply formulae
		double a = Math.pow(Math.sin(dLat / 2), 2) + Math.pow(Math.sin(dLon / 2), 2) * Math.cos(lat1) * Math.cos(lat2);
		double rad = 6371;
		double c = 2 * Math.asin(Math.sqrt(a));
		return rad * c;
	}

	public void addArrival(FlightEntity f) {
		String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		double time = f.getDistance() / 720;
		double finalTime = Math.round(time * 100) / 100;
		int firstPlace = (int) finalTime;
		double afterDecimal = finalTime - firstPlace;
        String var = f.getDepartureTime();
        var = var.replace(':', '.');
		double time2 = Double.parseDouble(var);
		int firstPlace2 = (int) time2;
		double afterDecimal2 = time2 - firstPlace2;

		if ((time + time2) > 24) {
			for (int i = 0; i < days.length; i++) {
				if (days[i].equalsIgnoreCase(f.getDepartureDay())) {
					f.setArrivalDay(days[(i + 1) % 7]);
				}
			}
		} else {
			f.setArrivalDay(f.getDepartureDay());
		}

		double lastTime = finalTime + time2;
		if (lastTime > 24) {
			int lastTimeVar = (int) (lastTime);
			double decVal = lastTime - lastTimeVar;
			if (decVal > 0.6) {
				lastTimeVar = +1;
				decVal = -0.6;
			}
			lastTimeVar = lastTimeVar - 24;
			int var3 = (int)lastTimeVar;
			int var4 = (int)decVal;
			String finalArrival = Integer.toString(var3) + ":" + Integer.toString(+var4);
			f.setArrivalTime(finalArrival);
		} else {
			int lastTimeVar = (int) lastTime;
			double decVal = lastTime - lastTimeVar;
			if (decVal > 0.6) {
				lastTimeVar = +1;
				decVal = -0.6;
			}
			String finalArrival = Double.toString(lastTimeVar) + ":" + Double.toString(+decVal);
			f.setArrivalTime(finalArrival);
		}

	}

	public void addDeparture(Flight f) {

	}

	/**
	 * Check to see if Flight f can depart from this location. If there is a clash,
	 * the clashing flight string is returned, otherwise null is returned. A
	 * conflict is determined by if any other flights are arriving or departing at
	 * this location within an hour of this flight's departure time.
	 * 
	 * @param f The flight to check.
	 * @return "Flight <id> [departing/arriving] from <name> on
	 *         <clashingFlightTime>". Return null if there is no clash.
	 */
	public String hasRunwayDepartureSpace(Flight f) {
		// check departures first

		// then check arrivals
		return "";
	}

	/**
	 * Check to see if Flight f can arrive at this location. A conflict is
	 * determined by if any other flights are arriving or departing at this location
	 * within an hour of this flight's arrival time.
	 * 
	 * @param f The flight to check.
	 * @return String representing the clashing flight, or null if there is no
	 *         clash. Eg. "Flight <id> [departing/arriving] from <name> on
	 *         <clashingFlightTime>"
	 */
	public String hasRunwayArrivalSpace(Flight f) {
		// check departures first

		// then check arrivals

		return "";
	}
}

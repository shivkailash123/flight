package flight;
import java.lang.Math;

public class Flight {
	// get the number of minutes this flight takes (round to nearest whole number)
	public int getDuration() {
        return 0;
	}

	// implement the ticket price formula
	public double getTicketPrice(String coff1,String coff2,FlightEntity flight) {
		double amount =0;
		double y=0;
		double x = ((flight.getBooked())/Double.parseDouble(flight.getCapacity()));
		if(flight.getBooked()==0) {
			amount = ((30+4*(Double.parseDouble(coff2)-Double.parseDouble(coff1)))*flight.getDistance())/100;
		}else if(x>0 && x<= 0.5) {
			y = -0.4*x+1;
			amount = y * (flight.getDistance()/100)*(30+4*((Double.parseDouble(coff2)-Double.parseDouble(coff1))));
		}else if(x>0.5 && x<=0.7) {
			y=x+0.3;
			amount = y * (flight.getDistance()/100)*(30+4*((Double.parseDouble(coff2)-Double.parseDouble(coff1))));
		}else {
			y=(0.2/3.14)*(Math.atan(20*x-14))+1;
			amount = y * (flight.getDistance()/100)*(30+4*((Double.parseDouble(coff2)-Double.parseDouble(coff1))));
		}
		
		return amount;

	}

	// book the given number of passengers onto this flight, returning the total
	// cost
	public double book(int num) {
       return 0;
	}

	// return whether or not this flight is full
	public boolean isFull() {
         return false;
	}

	// get the distance of this flight in km
	public double getDistance() {
        return 0;
	}

	// get the layover time, in minutes, between two flights
	public static int layover(Flight x, Flight y) {
         return 0;
	}
}

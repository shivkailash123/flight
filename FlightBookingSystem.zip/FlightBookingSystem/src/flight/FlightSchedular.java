package flight;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FlightSchedular {
	public static Scanner sc = new Scanner(System.in);
	private static FlightSchedular instance;
	int id = 0;

	List<FlightEntity> flight = new ArrayList<FlightEntity>();
	List<LocationEntity> locationEntities = new ArrayList<LocationEntity>();;

	public static void main(String[] args) {
		instance = new FlightSchedular(args);
		instance.run();
	}

	public static FlightSchedular getInstance() {
		return instance;
	}

	public FlightSchedular(String[] args) {
	}

	public void run() {
		// Do not use System.exit() anywhere in your code,
		// otherwise it will also exit the auto test suite.
		// Also, do not use static attributes otherwise
		// they will maintain the same values between testcases.

		// START YOUR CODE HERE

		boolean flag = true;
		while (flag) {
			System.out.println("1.Import Flight");
			System.out.println("2.Import Location");
			System.out.println("3. Get Flight Enter Id:");
			System.out.println("4. Add Location");
			System.out.println("5. Add Flight");
			System.out.println("6. Flights");
			System.out.println("7 Book Seat to Flight");
			System.out.println("8. Schedule");
			System.out.println("9. Arrival");
			System.out.println("10. Departure");
			System.out.println("11. Exit");
			int value = sc.nextInt();
			switch (value) {
			case 1:
				String[] command = { "", "", "C:\\Users\\M1057719\\Downloads\\flight.csv", "" };
				importFlights(command);
				addDistanceToFlight();
				addArivalToFlight();
				break;
			case 2:
				String[] command1 = { "", "", "C:\\Users\\M1057719\\Downloads\\location.csv", "" };
				importLocations(command1);
				break;
			case 3:
				System.out.println("Enter Id ");
				int varId = sc.nextInt();
				addDistanceToFlight();
				addArivalToFlight();
				getFlightUsingId(varId);

				break;
			case 4:
				addLocationMethod();
				break;
			case 5:
				addFlightMethod();
				break;
			case 6:
				printFlight();
				break;
			case 7:
				bookSeat();
				break;

			case 8:
				schedule();
				break;
			case 9:
				departure();
				break;
			case 10:
				arrival();
				break;
			case 11:
				flag = false;
				break;
			default:
				System.out.println("Please enter valid input");
				break;
			}
		}
	}

	private void arrival() {
		System.out.println("Enter Schedule at:");
		String schedule = sc.next();
		System.out.println("-------------------------------------------------------------------------");
		System.out.print("ID     ");
		System.out.print("Time    ");
		System.out.println("Departure/Arrival  ");
		System.out.println("--------------------------------------------------------------------------");
		for (FlightEntity flightVar : flight) {
			if (flightVar.getDestination().equalsIgnoreCase(schedule)) {
				System.out.print(flightVar.getId() + "    ");
				System.out.print(flightVar.getArrivalDay()+"      ");
				System.out.print(flightVar.getArrivalTime()+"      ");
				System.out.print("Arrive From " + flightVar.getDestination()+"      ");
				System.out.println();
			}
		}
	}

	private void departure() {
		System.out.println("Enter Schedule at:");
		String schedule = sc.next();
		System.out.println("-------------------------------------------------------------------------");
		System.out.print("ID     ");
		System.out.print("Time    ");
		System.out.print("Departure/Arrival  ");
		System.out.println("--------------------------------------------------------------------------");
		for (FlightEntity flightVar : flight) {
			if (flightVar.getSource().equalsIgnoreCase(schedule)) {
			
				System.out.print(flightVar.getId() + "    "); 
				System.out.print(flightVar.getDepartureDay() + "      ");
				System.out.print(flightVar.getArrivalTime() + "      ");
				System.out.print("Depart to " + flightVar.getSource() + "  ");
				System.out.println();
			}
			
		}
	}

	private void schedule() {
		System.out.println("Enter Schedule at:");
		String schedule = sc.next();
		System.out.println("-------------------------------------------------------------------------");
		System.out.print("ID     ");
		System.out.print("Time    ");
		System.out.println("Departure/Arrival  ");
		System.out.println("--------------------------------------------------------------------------");
		
		for (FlightEntity flightVar : flight) {
			if (flightVar.getSource().equalsIgnoreCase(schedule)) {
				
				System.out.print(flightVar.getId() + "    ");
				System.out.print(flightVar.getDepartureDay() + "        ");
				System.out.print(flightVar.getArrivalTime() + "        ");
				System.out.print("Depart to " + flightVar.getSource() + "  ");
				System.out.println();
				
			}
			
		}

		for (FlightEntity flightVar : flight) {
			if (flightVar.getDestination().equalsIgnoreCase(schedule)) {
				System.out.print(flightVar.getId() + "    ");
				System.out.print(flightVar.getArrivalDay());
				System.out.print(flightVar.getArrivalTime());
				System.out.print("Arrive From " + flightVar.getDestination());
				System.out.println();
			}
		}

	}

	private void bookSeat() {
		try {

			System.out.println("Enter Flight Id");
			id = sc.nextInt();
			System.out.println("Enter Number of seat");
			int numberOfSeat = sc.nextInt();

			FlightEntity flightEntity = new FlightEntity();

			String coff1 = "";
			String coff2 = "";
			for (FlightEntity flightVar : flight) {
				if (flightVar.getId() == id) {
					flightEntity = flightVar;
				}
			}

			for (LocationEntity locationVar : locationEntities) {
				if (flightEntity.getSource().equalsIgnoreCase(locationVar.getLocationName())) {
					coff1 = locationVar.getDemandCofficient();
					break;
				}
			}

			for (LocationEntity locationVar : locationEntities) {
				if (flightEntity.getDestination().equalsIgnoreCase(locationVar.getLocationName())) {
					coff2 = locationVar.getDemandCofficient();
					break;
				}
			}

			double totalAmount = 0;
			Flight flightVar1 = new Flight();
			for (FlightEntity flightVar : flight) {
				if (flightVar.getId() == id) {
					for (int i = 0; i < numberOfSeat; i++) {
						totalAmount = totalAmount + flightVar1.getTicketPrice(coff1, coff2, flightVar);
					}
					flightVar.setBooked(flightVar.getBooked() + numberOfSeat);
				}
				break;
			}

			System.out.println(
					"Booked " + numberOfSeat + " Passenger on flight " + id + " for a total cost of " + totalAmount);
			;

		} catch (Exception io) {
			System.out.println("Please Enter valid input");
		}

	}

	private void printFlight() {
		System.out.println("------------------------------------------------------------------");
		System.out.print("ID    ");
		System.out.print("Departure      ");
		System.out.print("Arrival      ");
		System.out.print("Source------>Destination");
		System.out.println("--------------------------------------------------------------------");

		for (FlightEntity flightVar : flight) {
			System.out.print(flightVar.getId() + "  ");
			System.out.print(flightVar.getDepartureDay() + " " + flightVar.getDepartureTime() + " ");
			System.out.print(flightVar.getArrivalDay() + " " + flightVar.getArrivalTime() + " ");
			System.out.print(flightVar.getSource() + "-------->" + flightVar.getDestination());
			System.out.println();
		}

	}

	private void addArivalToFlight() {
		Location flightObj = new Location();
		for (FlightEntity flightVar : flight) {
			flightObj.addArrival(flightVar);
		}

	}

	private void addFlightMethod() {
		try {
			String depDay = null;
			String depTime = null;
			String source = null;
			String destination = "";
			String capString = "";
			int booked = 0;

			depDay = sc.next();
			depTime = sc.next();
			source = sc.next();
			destination = sc.next();
			capString = sc.next();

			FlightEntity flightEntity = new FlightEntity(id, depDay, depTime, " ", " ", source, destination, capString,
					booked);
			checkIsPresent(flightEntity);
			flight.add(flightEntity);
			id++;
		} catch (Exception e) {
			System.out.println("enter valid input");
			return;
		}

	}

	private void checkIsPresent(FlightEntity flightEntity) {
		for (FlightEntity flightVar : flight) {
			String var = flightEntity.getDepartureTime();
			var = var.replace(':', '.');

			String var1 = flightVar.getArrivalTime();
			var1 = var1.replace(':', '.');

			double arrivalTime = Double.parseDouble(var);
			double departureTime = Double.parseDouble(var1);
			if (flightVar.getDestination().equalsIgnoreCase(flightEntity.getSource())) {
				if ((arrivalTime - departureTime) <= 1) {
					System.out.println("Scheduling conflict! This Flight clashesh");
				}
			}
		}

	}

	private void addLocationMethod() {
		try {
			String name;
			String lat;
			String lon;
			String coff;
			name = sc.next();
			lat = sc.next();
			lon = sc.next();
			coff = sc.next();

			LocationEntity locationEntity = new LocationEntity(name, lat, lon, coff);
			locationEntities.add(locationEntity);

		} catch (Exception e) {
			System.out.println("Please add valid Input");
			return;
		}

	}

	private void getFlightUsingId(int varId) {
		try {
			FlightEntity flightEntity = new FlightEntity();
			Flight flightCall = new Flight();
			String coff1 = "";
			String coff2 = "";
			for (FlightEntity flightVar : flight) {
				if (flightVar.getId() == varId) {
					flightEntity = flightVar;
				}
			}

			for (LocationEntity locationVar : locationEntities) {
				if (flightEntity.getSource().equalsIgnoreCase(locationVar.getLocationName())) {
					coff1 = locationVar.getDemandCofficient();
					break;
				}
			}

			for (LocationEntity locationVar : locationEntities) {
				if (flightEntity.getDestination().equalsIgnoreCase(locationVar.getLocationName())) {
					coff2 = locationVar.getDemandCofficient();
					break;
				}
			}

			double amount = flightCall.getTicketPrice(coff1, coff2, flightEntity);

			for (FlightEntity flightVar : flight) {
				if (flightVar.getId() == varId) {
					flightVar.setTicketCost(amount);
			
					System.out.println("Flight " + (varId));
					System.out.println("Departure: " + flightVar.getSource());
					System.out.println("Arrival: " + flightVar.getDestination());
					System.out.println("Distance: " + flightVar.getDistance());
					System.out.println("Ticket: " + flightVar.getTicketCost());
					System.out.println("Passenger: " + ((flightVar.getBooked())) + "/" + flightVar.getCapacity());
					flightVar.setBooked(flightVar.getBooked() + 1);
				}
			}
		} catch (Exception e) {
			System.out.println("Id not found");
			return;
		}

	}

	// Add a flight to the database
	// handle error cases and return status negative if error
	// (different status codes for different messages)
	// do not print out anything in this function
	public int addFlight(String date1, String date2, String start, String end, String capacity, int booked) {
		// check scheduling conflicts for starting location first, the ending location.

		FlightEntity flightEntity = new FlightEntity(id, date1, date2, " ", " ", start, end, capacity, booked);
		flight.add(flightEntity);
		id++;
		return 1;
	}

	// Add a location to the database
	// do not print out anything in this function
	// return negative numbers for error cases
	public int addLocation(String name, String lat, String lon, String demand) {

		LocationEntity locationEntity = new LocationEntity(name, lat, lon, demand);
		locationEntities.add(locationEntity);
		return 1;
	}

	// adding distance to flight
	public void addDistanceToFlight() {
		Location location = new Location();
		LocationEntity location1 = new LocationEntity();
		LocationEntity location2 = new LocationEntity();
		for (FlightEntity flightVar : flight) {
			int count = 0;
			String var1 = flightVar.getSource();
			String var2 = flightVar.getDestination();
			for (LocationEntity locationVar : locationEntities) {
				if (locationVar.getLocationName().equalsIgnoreCase(var1)) {
					location1 = locationVar;
				}
			}
			for (LocationEntity locationVar : locationEntities) {
				if (locationVar.getLocationName().equalsIgnoreCase(var2)) {
					location2 = locationVar;
				}
			}
			double distance = location.distance(location1, location2);
			flightVar.setDistance(distance);
		}

	}

	// flight import <filename>
	public void importFlights(String[] command) {
		try {
//			System.out.println(command.length);
			if (command.length < 3)
				throw new FileNotFoundException();
			// FileReader fr = new FileReader(new File(command[2]));
			System.out.println(command[2]);
			BufferedReader br = new BufferedReader(new FileReader(new File(command[2])));
			String line;
			int count = 0;
			int err = 0;

			while ((line = br.readLine()) != null) {
				String[] lparts = line.split(",");
				if (lparts.length < 5)
					continue;
				String[] dparts = lparts[0].split(" ");
				if (dparts.length < 2)
					continue;
				int booked = 0;

				try {
					booked = Integer.parseInt(lparts[4]);

				} catch (NumberFormatException e) {
					continue;
				}

				int status = addFlight(dparts[0], dparts[1], lparts[1], lparts[2], lparts[3], booked);
				if (status < 0) {
					err++;
					continue;
				}
				count++;
			}
			br.close();
			System.out.println("Imported " + count + " flight" + (count != 1 ? "s" : "") + ".");
			if (err > 0) {
				if (err == 1)
					System.out.println("1 line was invalid.");
				else
					System.out.println(err + " lines were invalid.");
			}
		} catch (IOException e) {

			System.out.println("Error reading file.");
			return;
		}
	}

	// location import <filename>
	public void importLocations(String[] command) {
		try {
			if (command.length < 3)
				throw new FileNotFoundException();
			BufferedReader br = new BufferedReader(new FileReader(new File(command[2])));
			String line;
			int count = 0;
			int err = 0;

			while ((line = br.readLine()) != null) {
				String[] lparts = line.split(",");
				if (lparts.length < 4)
					continue;

				int status = addLocation(lparts[0], lparts[1], lparts[2], lparts[3]);
				if (status < 0) {
					err++;
					continue;
				}
				count++;
			}
			br.close();
			System.out.println("Imported " + count + " location" + (count != 1 ? "s" : "") + ".");
			if (err > 0) {
				if (err == 1)
					System.out.println("1 line was invalid.");
				else
					System.out.println(err + " lines were invalid.");
			}

		} catch (IOException e) {
			System.out.println("Error reading file.");
			return;
		}
	}

}

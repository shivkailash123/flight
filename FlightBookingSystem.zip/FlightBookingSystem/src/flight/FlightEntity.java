package flight;

import java.sql.Time;
import java.util.Date;

public class FlightEntity {
	int id;
	String departureDay;
	String departureTime;
	String arrivalDay;
	String arrivalTime;
	String source;
	String Destination;
	String capacity;
	int booked;
	double distance;
	Time duration;
	double ticketCost;
	
	@Override
	public String toString() {
		return "FlightEntity [id=" + id + ", departureDay=" + departureDay + ", departureTime=" + departureTime
				+ ", arrivalDay=" + arrivalDay + ", arrivalTime=" + arrivalTime + ", source=" + source
				+ ", Destination=" + Destination + ", capacity=" + capacity + ", booked=" + booked + ", distance="
				+ distance + ", duration=" + duration + ", ticketCost=" + ticketCost + "]";
	}

	public FlightEntity() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDepartureDay() {
		return departureDay;
	}

	public void setDepartureDay(String departureDay) {
		this.departureDay = departureDay;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalDay() {
		return arrivalDay;
	}

	public void setArrivalDay(String arrivalDay) {
		this.arrivalDay = arrivalDay;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return Destination;
	}

	public void setDestination(String destination) {
		Destination = destination;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public int getBooked() {
		return booked;
	}

	public void setBooked(int booked) {
		this.booked = booked;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public Time getDuration() {
		return duration;
	}

	public void setDuration(Time duration) {
		this.duration = duration;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public FlightEntity(int id, String departureDay, String departureTime, String arrivalDay, String arrivalTime,
			String source, String destination, String capacity, int booked) {
		super();
		this.id = id;
		this.departureDay = departureDay;
		this.departureTime = departureTime;
		this.arrivalDay = arrivalDay;
		this.arrivalTime = arrivalTime;
		this.source = source;
		Destination = destination;
		this.capacity = capacity;
		this.booked = booked;
	}

}
